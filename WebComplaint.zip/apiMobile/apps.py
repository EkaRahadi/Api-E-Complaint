from django.apps import AppConfig


class ApimobileConfig(AppConfig):
    name = 'apiMobile'
