from django.apps import AppConfig


class ApiwebConfig(AppConfig):
    name = 'apiWeb'
